ComfyUI Feishu Batch Audio Workflow

Contents
- ComfyUIFeishuBatchAudio.json

Required workflow nodes
- comfyui-feishu-table
- ComfyUI Easy Use
- Comfyroll Custom Nodes
- Stable Audio 3 and the utility nodes referenced by the embedded generation subgraph

Before use
- Enter your own Feishu App ID, App Secret, and table URL in FeishuConfigNode.
- Set the output folder and verify the table field names used by the extraction nodes.
- The workflow references the local codex_silent_audio_save custom node used by this setup.

The packaged workflow contains no Feishu credentials or table URL.
