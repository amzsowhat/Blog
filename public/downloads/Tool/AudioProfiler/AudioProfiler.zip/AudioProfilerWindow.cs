using UnityEditor;
using UnityEngine;
using UnityEngine.Audio;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

public class AudioProfilerWindow : EditorWindow
{
    private class SourceProbe
    {
        public AudioClip clip;
        public int timeSamples;
        public bool initialized;
    }

    private class AudioPlaybackEvent
    {
        public string clipName;
        public string gameObjectName;
        public string hierarchyPath;
        public string mixerGroupName;
        public double startTime;
        public double? endTime;
        public AudioSource source;
        public AudioClip clip;
        public int lastTimeSamples;
        public bool isLooping;
        public AudioMixerGroup mixerGroup;
        public Color color;
        public AudioPlaybackEvent captureCopy;
    }

    [Serializable]
    private class ExportSession
    {
        public string format = "AudioProfilerSession/1";
        public string createdAt;
        public double durationSeconds;
        public int eventCount;
        public List<ExportEvent> events = new List<ExportEvent>();
    }

    [Serializable]
    private class ExportEvent
    {
        public string clip;
        public string gameObject;
        public string hierarchyPath;
        public string mixerGroup;
        public double startSeconds;
        public double endSeconds;
        public double sustainSeconds;
        public bool loop;
    }

    private readonly List<AudioPlaybackEvent> playbackEvents = new List<AudioPlaybackEvent>();
    private readonly List<AudioPlaybackEvent> capturedEvents = new List<AudioPlaybackEvent>();
    private readonly Dictionary<AudioSource, AudioPlaybackEvent> activeSources = new Dictionary<AudioSource, AudioPlaybackEvent>();
    private readonly Dictionary<AudioMixerGroup, Color> mixerGroupColors = new Dictionary<AudioMixerGroup, Color>();
    private readonly Dictionary<AudioSource, SourceProbe> sourceProbes = new Dictionary<AudioSource, SourceProbe>();
    private readonly HashSet<AudioSource> seenSources = new HashSet<AudioSource>();
    private readonly List<AudioSource> staleSources = new List<AudioSource>();

    private Vector2 scrollPosition;
    private float minimumTimelineSeconds = 10f;
    private float pixelsPerSecond = 100f;
    private bool isRecording;
    private bool showCapture;
    private bool mergeRepeatedClips = true;
    private string searchFilter = "";

    private double liveTimelineTime;
    private double playSegmentEditorStart;
    private bool playSegmentActive;
    private double captureStartTime;
    private double capturedDuration;
    private double lastScanEditorTime;
    private double lastRepaintEditorTime;
    private double lastScanDurationMs;
    private int totalSourcesLastScan;

    private GUIStyle busLabelStyle;
    private GUIStyle trackLabelStyle;
    private GUIStyle clipLabelStyle;
    private GUIStyle durationLabelStyle;
    private GUIStyle statusLabelStyle;
    private GUIStyle centeredMessageStyle;

    private const double scanInterval = 1d / 30d;
    private const double repaintInterval = 1d / 60d;
    private const int maxRecordedEvents = 10000;

    private const float leftPanelWidth = 230f;
    private const float timelineHeight = 44f;
    private const float busHeaderHeight = 26f;
    private const float timeRulerHeight = 28f;
    private const float rightPadding = 20f;

    private static readonly Color WindowBackground = new Color(0.105f, 0.112f, 0.125f);
    private static readonly Color RulerBackground = new Color(0.075f, 0.082f, 0.094f);
    private static readonly Color HeaderBackground = new Color(0.135f, 0.145f, 0.165f);
    private static readonly Color RowEven = new Color(0.12f, 0.128f, 0.145f);
    private static readonly Color RowOdd = new Color(0.145f, 0.153f, 0.172f);
    private static readonly Color GridMajor = new Color(1f, 1f, 1f, 0.105f);
    private static readonly Color GridMinor = new Color(1f, 1f, 1f, 0.045f);
    private static readonly Color PlayheadColor = new Color(1f, 0.31f, 0.22f, 1f);

    [MenuItem("AudioTools/Audio Profiler Timeline")]
    public static void ShowWindow()
    {
        AudioProfilerWindow window = GetWindow<AudioProfilerWindow>("Audio Profiler");
        window.minSize = new Vector2(420f, 240f);
    }

    private void OnEnable()
    {
        minSize = new Vector2(420f, 240f);
        EditorApplication.update += UpdateAudioEvents;
        EditorApplication.playModeStateChanged += OnPlayModeStateChanged;
        EditorApplication.pauseStateChanged += OnPauseStateChanged;
    }

    private void OnDisable()
    {
        EditorApplication.update -= UpdateAudioEvents;
        EditorApplication.playModeStateChanged -= OnPlayModeStateChanged;
        EditorApplication.pauseStateChanged -= OnPauseStateChanged;
        if (isRecording)
            StopRecording(false);
    }

    private void OnPlayModeStateChanged(PlayModeStateChange state)
    {
        if (state == PlayModeStateChange.EnteredPlayMode)
        {
            playbackEvents.Clear();
            activeSources.Clear();
            sourceProbes.Clear();
            liveTimelineTime = 0d;
            playSegmentEditorStart = EditorApplication.timeSinceStartup;
            playSegmentActive = true;
            lastScanEditorTime = 0d;
            showCapture = false;
        }

        if (state == PlayModeStateChange.ExitingPlayMode)
        {
            double endTime = GetTimelineTime();
            liveTimelineTime = endTime;
            playSegmentActive = false;
            FinalizeActiveEvents(endTime);
            if (isRecording)
                StopRecording(false);
        }

        Repaint();
    }

    private void OnPauseStateChanged(PauseState state)
    {
        if (state == PauseState.Paused)
        {
            double pauseTime = GetTimelineTime();
            liveTimelineTime = pauseTime;
            playSegmentActive = false;
            FinalizeActiveEvents(pauseTime);
        }
        else if (EditorApplication.isPlaying)
        {
            playSegmentEditorStart = EditorApplication.timeSinceStartup;
            playSegmentActive = true;
            sourceProbes.Clear();
            lastScanEditorTime = 0d;
        }
        Repaint();
    }

    private void SetupStyles()
    {
        busLabelStyle = new GUIStyle(EditorStyles.boldLabel)
        {
            fontSize = 12,
            alignment = TextAnchor.MiddleLeft,
            normal = { textColor = new Color(0.91f, 0.93f, 0.97f) }
        };

        trackLabelStyle = new GUIStyle(EditorStyles.label)
        {
            fontSize = 11,
            clipping = TextClipping.Clip,
            normal = { textColor = new Color(0.93f, 0.94f, 0.97f) }
        };

        clipLabelStyle = new GUIStyle(EditorStyles.miniLabel)
        {
            clipping = TextClipping.Clip,
            normal = { textColor = new Color(0.62f, 0.68f, 0.77f) }
        };

        durationLabelStyle = new GUIStyle(EditorStyles.miniBoldLabel)
        {
            alignment = TextAnchor.MiddleCenter,
            clipping = TextClipping.Clip,
            normal = { textColor = Color.white }
        };

        statusLabelStyle = new GUIStyle(EditorStyles.miniLabel)
        {
            alignment = TextAnchor.MiddleLeft,
            normal = { textColor = new Color(0.66f, 0.71f, 0.79f) }
        };

        centeredMessageStyle = new GUIStyle(EditorStyles.centeredGreyMiniLabel)
        {
            alignment = TextAnchor.MiddleCenter,
            fontSize = 12
        };
    }

    private void UpdateAudioEvents()
    {
        if (!EditorApplication.isPlaying || EditorApplication.isPaused) return;

        if (!playSegmentActive)
        {
            playSegmentEditorStart = EditorApplication.timeSinceStartup;
            playSegmentActive = true;
        }

        double editorNow = EditorApplication.timeSinceStartup;
        if (editorNow - lastRepaintEditorTime >= repaintInterval)
        {
            lastRepaintEditorTime = editorNow;
            Repaint();
        }

        if (editorNow - lastScanEditorTime < scanInterval) return;

        lastScanEditorTime = editorNow;
        ScanAudioSources(GetTimelineTime());
    }

    private void ScanAudioSources(double currentTime)
    {
        double scanStarted = EditorApplication.timeSinceStartup;
        AudioSource[] sources = Resources.FindObjectsOfTypeAll<AudioSource>();
        totalSourcesLastScan = 0;
        seenSources.Clear();

        foreach (AudioSource src in sources)
        {
            if (src == null) continue;
            if (!src.gameObject.scene.IsValid()) continue;
            totalSourcesLastScan++;
            seenSources.Add(src);

            int timeSamples = GetSafeTimeSamples(src);
            SourceProbe probe;
            if (!sourceProbes.TryGetValue(src, out probe))
            {
                probe = new SourceProbe();
                sourceProbes[src] = probe;
            }

            bool sameClip = probe.initialized && probe.clip == src.clip;
            bool samplesMovedForward = sameClip && timeSamples > probe.timeSamples;
            bool loopWrapped = sameClip && src.loop && timeSamples + 256 < probe.timeSamples;
            bool sourceIsPlaying = src.isPlaying || samplesMovedForward || loopWrapped;

            if (sourceIsPlaying)
            {
                AudioPlaybackEvent activeEvent;
                bool hasActiveEvent = activeSources.TryGetValue(src, out activeEvent);
                bool clipChanged = hasActiveEvent && activeEvent.clip != src.clip;
                bool restarted = src.isPlaying && hasActiveEvent && !activeEvent.isLooping &&
                                 timeSamples + 256 < activeEvent.lastTimeSamples;

                if (clipChanged || restarted)
                {
                    EndEvent(activeEvent, currentTime);
                    activeSources.Remove(src);
                    hasActiveEvent = false;
                }

                if (!hasActiveEvent)
                {
                    activeEvent = CreateEvent(src, currentTime);
                    playbackEvents.Add(activeEvent);
                    activeSources[src] = activeEvent;
                    TrimRecordedEvents();
                }
                else
                {
                    activeEvent.lastTimeSamples = timeSamples;
                }
            }
            else
            {
                AudioPlaybackEvent activeEvent;
                if (activeSources.TryGetValue(src, out activeEvent))
                {
                    EndEvent(activeEvent, currentTime);
                    activeSources.Remove(src);
                }
            }

            probe.clip = src.clip;
            probe.timeSamples = timeSamples;
            probe.initialized = true;
        }

        staleSources.Clear();
        foreach (KeyValuePair<AudioSource, AudioPlaybackEvent> pair in activeSources)
        {
            if (pair.Key == null || !seenSources.Contains(pair.Key))
            {
                EndEvent(pair.Value, currentTime);
                staleSources.Add(pair.Key);
            }
        }

        foreach (AudioSource source in staleSources)
        {
            activeSources.Remove(source);
            sourceProbes.Remove(source);
        }

        staleSources.Clear();
        foreach (AudioSource source in sourceProbes.Keys)
        {
            if (source == null || !seenSources.Contains(source))
                staleSources.Add(source);
        }
        foreach (AudioSource source in staleSources)
            sourceProbes.Remove(source);

        lastScanDurationMs = (EditorApplication.timeSinceStartup - scanStarted) * 1000d;
    }

    private int GetSafeTimeSamples(AudioSource source)
    {
        try
        {
            return source != null ? Mathf.Max(0, source.timeSamples) : 0;
        }
        catch
        {
            return 0;
        }
    }

    private AudioPlaybackEvent CreateEvent(AudioSource source, double currentTime)
    {
        AudioMixerGroup group = source.outputAudioMixerGroup;
        AudioClip clip = source.clip;
        AudioPlaybackEvent playbackEvent = new AudioPlaybackEvent
        {
            clipName = clip != null ? clip.name : "(PlayOneShot / Unknown Clip)",
            gameObjectName = source.gameObject.name,
            hierarchyPath = GetHierarchyPath(source.transform),
            mixerGroupName = group != null ? group.name : "(No Bus)",
            startTime = currentTime,
            source = source,
            clip = clip,
            lastTimeSamples = GetSafeTimeSamples(source),
            isLooping = source.loop,
            mixerGroup = group,
            color = GetCachedGroupColor(group)
        };
        if (isRecording)
            AttachCaptureCopy(playbackEvent, Math.Max(0d, currentTime - captureStartTime));

        return playbackEvent;
    }

    private void EndEvent(AudioPlaybackEvent playbackEvent, double endTime)
    {
        if (playbackEvent == null || playbackEvent.endTime.HasValue) return;
        playbackEvent.endTime = endTime;

        if (playbackEvent.captureCopy != null)
        {
            playbackEvent.captureCopy.endTime = Math.Max(0d, endTime - captureStartTime);
            playbackEvent.captureCopy = null;
        }
    }

    private void AttachCaptureCopy(AudioPlaybackEvent sourceEvent, double relativeStartTime)
    {
        if (sourceEvent == null || sourceEvent.captureCopy != null) return;

        AudioPlaybackEvent copy = new AudioPlaybackEvent
        {
            clipName = sourceEvent.clipName,
            gameObjectName = sourceEvent.gameObjectName,
            hierarchyPath = sourceEvent.hierarchyPath,
            mixerGroupName = sourceEvent.mixerGroupName,
            startTime = relativeStartTime,
            source = sourceEvent.source,
            clip = sourceEvent.clip,
            lastTimeSamples = sourceEvent.lastTimeSamples,
            isLooping = sourceEvent.isLooping,
            mixerGroup = sourceEvent.mixerGroup,
            color = sourceEvent.color
        };
        sourceEvent.captureCopy = copy;
        capturedEvents.Add(copy);
    }

    private void TrimRecordedEvents()
    {
        while (playbackEvents.Count > maxRecordedEvents)
        {
            int removableIndex = playbackEvents.FindIndex(item => item.endTime.HasValue);
            if (removableIndex < 0) return;
            playbackEvents.RemoveAt(removableIndex);
        }
    }

    private Color GetCachedGroupColor(AudioMixerGroup group)
    {
        if (group == null) return new Color(0.43f, 0.49f, 0.58f, 1f);

        Color color;
        if (!mixerGroupColors.TryGetValue(group, out color))
        {
            float hue = Mathf.Abs(group.GetInstanceID() * 0.61803398875f) % 1f;
            color = Color.HSVToRGB(hue, 0.55f, 0.88f);
            color.a = 1f;
            mixerGroupColors[group] = color;
        }
        return color;
    }

    private void OnGUI()
    {
        if (busLabelStyle == null) SetupStyles();

        EditorGUI.DrawRect(new Rect(0f, 0f, position.width, position.height), WindowBackground);
        DrawToolbar();
        DrawStatusBar();
        DrawTimeline();
    }

    private void DrawToolbar()
    {
        GUILayout.BeginHorizontal(EditorStyles.toolbar, GUILayout.Height(24f));

        if (GUILayout.Toggle(!showCapture, "LIVE", EditorStyles.toolbarButton, GUILayout.Width(48f)))
            showCapture = false;

        GUI.enabled = capturedEvents.Count > 0 || isRecording;
        if (GUILayout.Toggle(showCapture, "CAPTURE", EditorStyles.toolbarButton, GUILayout.Width(66f)))
            showCapture = true;
        GUI.enabled = true;

        GUILayout.Space(6f);
        Color previousColor = GUI.color;
        GUI.color = isRecording ? new Color(1f, 0.48f, 0.42f) : Color.white;
        GUI.enabled = EditorApplication.isPlaying && !EditorApplication.isPaused;
        bool recordClicked = GUILayout.Button(isRecording ? "■ STOP" : "● REC", EditorStyles.toolbarButton, GUILayout.Width(62f));
        GUI.enabled = true;
        GUI.color = previousColor;

        if (recordClicked)
        {
            if (!isRecording) StartRecording();
            else StopRecording(true);
        }

        if (GUILayout.Button(new GUIContent("Stop Audio", "停止场景内全部 AudioSource"), EditorStyles.toolbarButton, GUILayout.Width(72f)))
            StopAllAudio();

        if (GUILayout.Button("Clear", EditorStyles.toolbarButton, GUILayout.Width(45f)))
            ClearSession();

        mergeRepeatedClips = GUILayout.Toggle(
            mergeRepeatedClips,
            new GUIContent("Merge", "同一 Mixer Group 内，相同 AudioClip 的多次触发合并到一条轨道"),
            EditorStyles.toolbarButton,
            GUILayout.Width(52f));

        GUI.enabled = capturedEvents.Count > 0;
        if (GUILayout.Button(new GUIContent("Export JSON", "导出 Capture 数据"), EditorStyles.toolbarButton, GUILayout.Width(78f)))
            ExportJson();
        GUI.enabled = true;

        GUILayout.Space(10f);
        searchFilter = GUILayout.TextField(searchFilter, EditorStyles.toolbarSearchField, GUILayout.MinWidth(120f), GUILayout.MaxWidth(240f));
        GUILayout.FlexibleSpace();

        GUILayout.Label("Zoom", EditorStyles.miniLabel);
        GUI.enabled = showCapture && !isRecording;
        pixelsPerSecond = GUILayout.HorizontalSlider(pixelsPerSecond, 35f, 500f, GUILayout.Width(100f));
        GUILayout.Label(Mathf.RoundToInt(pixelsPerSecond) + " px/s", EditorStyles.miniLabel, GUILayout.Width(55f));
        GUI.enabled = true;

        GUILayout.EndHorizontal();
    }

    private void DrawStatusBar()
    {
        string state;
        Color stateColor;
        if (isRecording)
        {
            state = "LIVE + CAPTURING";
            stateColor = new Color(1f, 0.42f, 0.35f);
        }
        else if (EditorApplication.isPlaying)
        {
            state = showCapture ? "CAPTURE REVIEW" : "LIVE MONITORING";
            stateColor = new Color(0.38f, 0.82f, 0.58f);
        }
        else
        {
            state = showCapture ? "CAPTURE REVIEW" : "PLAY STOPPED";
            stateColor = new Color(0.52f, 0.72f, 0.94f);
        }

        Rect statusRect = GUILayoutUtility.GetRect(0f, 24f, GUILayout.ExpandWidth(true));
        EditorGUI.DrawRect(statusRect, HeaderBackground);
        Rect dotRect = new Rect(statusRect.x + 9f, statusRect.center.y - 3f, 6f, 6f);
        EditorGUI.DrawRect(dotRect, stateColor);
        GUI.Label(new Rect(statusRect.x + 20f, statusRect.y, 150f, statusRect.height), state, statusLabelStyle);

        string metrics = string.Format(
            "Voices {0}   Sources {1}   Events {2}   Scan {3:0.00} ms @ 30 Hz   UI ~60 Hz",
            activeSources.Count,
            totalSourcesLastScan,
            showCapture ? capturedEvents.Count : playbackEvents.Count,
            lastScanDurationMs);
        GUI.Label(new Rect(statusRect.x + 170f, statusRect.y, Mathf.Max(0f, statusRect.width - 178f), statusRect.height), metrics, statusLabelStyle);
    }

    private void StartRecording()
    {
        if (!EditorApplication.isPlaying || EditorApplication.isPaused || isRecording) return;

        double liveTime = GetTimelineTime();
        ScanAudioSources(liveTime);
        capturedEvents.Clear();
        captureStartTime = liveTime;
        capturedDuration = 0d;
        isRecording = true;
        showCapture = false;

        foreach (AudioPlaybackEvent activeEvent in activeSources.Values)
            AttachCaptureCopy(activeEvent, 0d);

        Repaint();
    }

    private void StopRecording(bool repaint)
    {
        if (!isRecording) return;

        capturedDuration = Math.Max(0d, GetTimelineTime() - captureStartTime);
        foreach (AudioPlaybackEvent activeEvent in activeSources.Values)
        {
            if (activeEvent.captureCopy == null) continue;
            activeEvent.captureCopy.endTime = capturedDuration;
            activeEvent.captureCopy = null;
        }
        isRecording = false;
        showCapture = true;
        if (repaint) Repaint();
    }

    private void StopAllAudio()
    {
        double currentTime = GetTimelineTime();
        FinalizeActiveEvents(currentTime);
        foreach (AudioSource source in FindObjectsOfType<AudioSource>())
        {
            if (source != null) source.Stop();
        }
        Repaint();
    }

    private void FinalizeActiveEvents(double endTime)
    {
        foreach (AudioPlaybackEvent activeEvent in activeSources.Values)
            EndEvent(activeEvent, endTime);
        activeSources.Clear();
    }

    private void ClearSession()
    {
        if (isRecording)
            StopRecording(false);
        playbackEvents.Clear();
        capturedEvents.Clear();
        activeSources.Clear();
        sourceProbes.Clear();
        mixerGroupColors.Clear();
        liveTimelineTime = 0d;
        playSegmentEditorStart = EditorApplication.timeSinceStartup;
        playSegmentActive = EditorApplication.isPlaying;
        captureStartTime = 0d;
        capturedDuration = 0d;
        showCapture = false;
        scrollPosition = Vector2.zero;
        Repaint();
    }

    private double GetTimelineTime()
    {
        if (playSegmentActive)
            return liveTimelineTime + Math.Max(0d, EditorApplication.timeSinceStartup - playSegmentEditorStart);
        return liveTimelineTime;
    }

    private void DrawTimeline()
    {
        List<AudioPlaybackEvent> displayEvents = showCapture ? capturedEvents : playbackEvents;
        double currentTime = showCapture
            ? (isRecording ? Math.Max(0d, GetTimelineTime() - captureStartTime) : capturedDuration)
            : GetTimelineTime();
        bool rollingView = (!showCapture && EditorApplication.isPlaying && !EditorApplication.isPaused) ||
                           (showCapture && isRecording);
        double viewStart = rollingView ? currentTime - minimumTimelineSeconds : 0d;
        double latestEventTime = displayEvents.Count == 0
            ? 0d
            : displayEvents.Max(item => item.endTime ?? currentTime);
        float contentSeconds = rollingView
            ? minimumTimelineSeconds
            : Mathf.Max(minimumTimelineSeconds, Mathf.Ceil((float)Math.Max(currentTime, latestEventTime) + 1f));
        float infoPanelWidth = rollingView
            ? Mathf.Clamp(position.width * 0.28f, 120f, leftPanelWidth)
            : leftPanelWidth;
        float timelineScale = rollingView
            ? Mathf.Max(20f, (position.width - infoPanelWidth - rightPadding - 20f) / minimumTimelineSeconds)
            : pixelsPerSecond;
        float timelineWidth = contentSeconds * timelineScale;
        float contentWidth = infoPanelWidth + timelineWidth + rightPadding;

        if (rollingView)
            scrollPosition.x = 0f;

        scrollPosition = GUILayout.BeginScrollView(scrollPosition, false, false);
        DrawTimeRuler(contentSeconds, contentWidth, currentTime, viewStart, infoPanelWidth, timelineScale);

        List<IGrouping<AudioMixerGroup, AudioPlaybackEvent>> groups = displayEvents
            .Where(item => !rollingView ||
                           ((item.endTime ?? currentTime) >= viewStart &&
                            item.startTime <= viewStart + contentSeconds))
            .Where(item => MatchesSearch(item.gameObjectName) || MatchesSearch(item.clipName))
            .GroupBy(item => item.mixerGroup)
            .OrderBy(group => group.Key != null ? group.Key.name : "zzz")
            .ToList();

        if (groups.Count == 0)
        {
            Rect emptyRect = GUILayoutUtility.GetRect(contentWidth, 110f);
            EditorGUI.DrawRect(emptyRect, RowEven);
            string message;
            if (showCapture)
                message = isRecording ? "Capturing… waiting for audio playback." : "No Capture data. Click REC during Play Mode to capture a segment.";
            else
                message = EditorApplication.isPlaying ? "LIVE monitoring — waiting for AudioSource playback…" : "Enter Play Mode to start LIVE monitoring.";
            GUI.Label(new Rect(emptyRect.x, emptyRect.y + 30f, Mathf.Min(position.width, emptyRect.width), 40f), message, centeredMessageStyle);
        }

        int rowIndex = 0;
        foreach (IGrouping<AudioMixerGroup, AudioPlaybackEvent> group in groups)
        {
            DrawBusHeader(group.Key, group.Count(), contentWidth, infoPanelWidth);

            List<List<AudioPlaybackEvent>> tracks;
            if (mergeRepeatedClips)
            {
                tracks = group
                    .GroupBy(GetMergedTrackKey)
                    .OrderBy(track => track.First().clipName)
                    .Select(track => track.OrderBy(item => item.startTime).ToList())
                    .ToList();
            }
            else
            {
                tracks = group
                    .OrderBy(item => item.gameObjectName)
                    .Select(item => new List<AudioPlaybackEvent> { item })
                    .ToList();
            }

            foreach (List<AudioPlaybackEvent> trackEvents in tracks)
            {
                DrawTrackRow(trackEvents, timelineWidth, currentTime, viewStart, infoPanelWidth, timelineScale, rowIndex++);
            }
        }

        GUILayout.Space(6f);
        GUILayout.EndScrollView();
    }

    private void DrawTimeRuler(float contentSeconds, float contentWidth, double currentTime, double viewStart, float infoPanelWidth, float timelineScale)
    {
        Rect rulerRect = GUILayoutUtility.GetRect(contentWidth, timeRulerHeight, GUILayout.Width(contentWidth));
        EditorGUI.DrawRect(rulerRect, RulerBackground);
        EditorGUI.DrawRect(new Rect(rulerRect.x, rulerRect.yMax - 1f, rulerRect.width, 1f), GridMajor);

        GUI.Label(new Rect(rulerRect.x + 10f, rulerRect.y, infoPanelWidth - 20f, rulerRect.height), showCapture ? "CAPTURE TIMELINE" : "LIVE TIMELINE", busLabelStyle);
        float timelineX = rulerRect.x + infoPanelWidth;
        int labelStep = timelineScale < 60f ? 2 : 1;

        int firstTimelineSecond = Mathf.Max(0, Mathf.CeilToInt((float)viewStart));
        int lastTimelineSecond = Mathf.CeilToInt((float)(viewStart + contentSeconds));
        for (int second = firstTimelineSecond; second <= lastTimelineSecond; second++)
        {
            float x = Mathf.Round(timelineX + (float)(second - viewStart) * timelineScale);
            Color lineColor = second % 5 == 0 ? GridMajor : GridMinor;
            EditorGUI.DrawRect(new Rect(x, rulerRect.y, 1f, rulerRect.height), lineColor);
            if (second % labelStep == 0)
                GUI.Label(new Rect(x + 4f, rulerRect.y, 75f, rulerRect.height), FormatRulerTime(second), statusLabelStyle);
        }

        float playheadX = Mathf.Round(timelineX + (float)(currentTime - viewStart) * timelineScale);
        playheadX = Mathf.Min(playheadX, timelineX + contentSeconds * timelineScale - 2f);
        EditorGUI.DrawRect(new Rect(playheadX, rulerRect.y, 2f, rulerRect.height), PlayheadColor);
    }

    private void DrawBusHeader(AudioMixerGroup group, int eventCount, float contentWidth, float infoPanelWidth)
    {
        Rect rect = GUILayoutUtility.GetRect(contentWidth, busHeaderHeight, GUILayout.Width(contentWidth));
        EditorGUI.DrawRect(rect, HeaderBackground);
        Color busColor = GetCachedGroupColor(group);
        EditorGUI.DrawRect(new Rect(rect.x, rect.y, 4f, rect.height), busColor);

        string name = group != null ? group.name : "No Bus";
        GUI.Label(new Rect(rect.x + 12f, rect.y, infoPanelWidth - 20f, rect.height), name, busLabelStyle);
        GUI.Label(new Rect(rect.x + infoPanelWidth, rect.y, 120f, rect.height), eventCount + (eventCount == 1 ? " event" : " events"), statusLabelStyle);
    }

    private string GetMergedTrackKey(AudioPlaybackEvent playbackEvent)
    {
        if (playbackEvent.clip != null)
            return "clip:" + playbackEvent.clip.GetInstanceID();
        return "unknown:" + playbackEvent.clipName + ":" + playbackEvent.gameObjectName;
    }

    private void DrawTrackRow(List<AudioPlaybackEvent> trackEvents, float timelineWidth, double currentTime, double viewStart, float infoPanelWidth, float timelineScale, int rowIndex)
    {
        if (trackEvents == null || trackEvents.Count == 0) return;
        AudioPlaybackEvent representative = trackEvents[0];

        GUILayout.BeginHorizontal(GUILayout.Height(timelineHeight));
        Rect infoRect = GUILayoutUtility.GetRect(infoPanelWidth, timelineHeight, GUILayout.Width(infoPanelWidth));
        Rect timelineRect = GUILayoutUtility.GetRect(timelineWidth, timelineHeight, GUILayout.Width(timelineWidth));
        GUILayout.Space(rightPadding);
        GUILayout.EndHorizontal();

        Color rowColor = rowIndex % 2 == 0 ? RowEven : RowOdd;
        EditorGUI.DrawRect(infoRect, rowColor);
        EditorGUI.DrawRect(timelineRect, rowColor);
        EditorGUI.DrawRect(new Rect(infoRect.xMax - 1f, infoRect.y, 1f, infoRect.height), GridMajor);
        EditorGUI.DrawRect(new Rect(infoRect.x, infoRect.yMax - 1f, infoRect.width + timelineRect.width, 1f), GridMinor);

        if (trackEvents.Count == 1)
        {
            GUI.Label(new Rect(infoRect.x + 10f, infoRect.y + 5f, infoRect.width - 18f, 19f), representative.gameObjectName, trackLabelStyle);
            GUI.Label(new Rect(infoRect.x + 10f, infoRect.y + 23f, infoRect.width - 18f, 16f), representative.clipName, clipLabelStyle);
        }
        else
        {
            int sourceCount = trackEvents.Select(item => item.gameObjectName).Distinct().Count();
            GUI.Label(new Rect(infoRect.x + 10f, infoRect.y + 5f, infoRect.width - 18f, 19f), representative.clipName, trackLabelStyle);
            GUI.Label(
                new Rect(infoRect.x + 10f, infoRect.y + 23f, infoRect.width - 18f, 16f),
                trackEvents.Count + " plays · " + sourceCount + (sourceCount == 1 ? " source" : " sources"),
                clipLabelStyle);
        }

        DrawTrackGrid(timelineRect, currentTime, viewStart, timelineScale);
        foreach (AudioPlaybackEvent playbackEvent in trackEvents)
            DrawAudioBlock(playbackEvent, timelineRect, currentTime, viewStart, timelineScale);
    }

    private void DrawTrackGrid(Rect area, double currentTime, double viewStart, float timelineScale)
    {
        int firstTimelineSecond = Mathf.Max(0, Mathf.CeilToInt((float)viewStart));
        int lastTimelineSecond = Mathf.CeilToInt((float)(viewStart + area.width / timelineScale));
        for (int second = firstTimelineSecond; second <= lastTimelineSecond; second++)
        {
            float x = Mathf.Round(area.x + (float)(second - viewStart) * timelineScale);
            EditorGUI.DrawRect(new Rect(x, area.y, 1f, area.height), second % 5 == 0 ? GridMajor : GridMinor);
        }

        float playheadX = Mathf.Round(area.x + (float)(currentTime - viewStart) * timelineScale);
        playheadX = Mathf.Min(playheadX, area.xMax - 2f);
        if (playheadX >= area.x && playheadX <= area.xMax)
            EditorGUI.DrawRect(new Rect(playheadX, area.y, 2f, area.height), PlayheadColor);
    }

    private void DrawAudioBlock(AudioPlaybackEvent playbackEvent, Rect area, double currentTime, double viewStart, float timelineScale)
    {
        double end = playbackEvent.endTime ?? currentTime;
        double duration = Math.Max(0d, end - playbackEvent.startTime);
        float rawStartX = area.x + (float)(playbackEvent.startTime - viewStart) * timelineScale;
        float rawEndX = area.x + (float)(end - viewStart) * timelineScale;
        if (!playbackEvent.endTime.HasValue && rawEndX >= area.xMax - 1f)
            rawStartX = Mathf.Min(rawStartX, area.xMax - 2f);
        float clippedStartX = Mathf.Max(rawStartX, area.x);
        float clippedEndX = Mathf.Min(rawEndX, area.xMax);
        Rect blockRect = new Rect(clippedStartX, area.y + 3f, clippedEndX - clippedStartX, area.height - 6f);
        if (blockRect.width <= 0f) return;
        if (blockRect.xMax < scrollPosition.x || blockRect.x > scrollPosition.x + position.width) return;

        Color fill = playbackEvent.color;
        fill.a = 0.48f;
        EditorGUI.DrawRect(blockRect, fill);
        EditorGUI.DrawRect(new Rect(blockRect.x, blockRect.y, blockRect.width, 2f), playbackEvent.color);

        float visibleMin = Mathf.Max(blockRect.x, scrollPosition.x);
        float visibleMax = Mathf.Min(blockRect.xMax, scrollPosition.x + position.width);
        if (visibleMax - visibleMin > 42f)
        {
            const float badgeWidth = 102f;
            float actualWidth = Mathf.Min(badgeWidth, visibleMax - visibleMin - 8f);
            float badgeX = Mathf.Clamp(blockRect.xMax - actualWidth - 4f, visibleMin + 4f, visibleMax - actualWidth - 4f);
            Rect badgeRect = new Rect(badgeX, blockRect.y + 4f, actualWidth, 18f);
            EditorGUI.DrawRect(badgeRect, new Color(0.035f, 0.04f, 0.05f, 0.94f));
            GUI.Label(badgeRect, FormatTimeWithMilliseconds(duration), durationLabelStyle);
        }
    }

    private bool MatchesSearch(string value)
    {
        return string.IsNullOrEmpty(searchFilter) ||
               (!string.IsNullOrEmpty(value) && value.IndexOf(searchFilter, StringComparison.OrdinalIgnoreCase) >= 0);
    }

    private string GetHierarchyPath(Transform transform)
    {
        if (transform == null) return "";
        string path = transform.name;
        while (transform.parent != null)
        {
            transform = transform.parent;
            path = transform.name + "/" + path;
        }
        return path;
    }

    private void ExportJson()
    {
        string path = EditorUtility.SaveFilePanel("Export Audio Profiler Session", "", "AudioProfilerSession.json", "json");
        if (string.IsNullOrEmpty(path)) return;

        double currentTime = isRecording
            ? Math.Max(0d, GetTimelineTime() - captureStartTime)
            : capturedDuration;
        ExportSession session = new ExportSession
        {
            createdAt = DateTime.Now.ToString("o"),
            durationSeconds = currentTime,
            eventCount = capturedEvents.Count
        };

        foreach (AudioPlaybackEvent playbackEvent in capturedEvents)
        {
            double end = playbackEvent.endTime ?? currentTime;
            session.events.Add(new ExportEvent
            {
                clip = playbackEvent.clipName,
                gameObject = playbackEvent.gameObjectName,
                hierarchyPath = playbackEvent.hierarchyPath,
                mixerGroup = playbackEvent.mixerGroupName,
                startSeconds = playbackEvent.startTime,
                endSeconds = end,
                sustainSeconds = Math.Max(0d, end - playbackEvent.startTime),
                loop = playbackEvent.isLooping
            });
        }

        File.WriteAllText(path, JsonUtility.ToJson(session, true), new UTF8Encoding(false));
        EditorUtility.RevealInFinder(path);
    }

    private string FormatRulerTime(int totalSeconds)
    {
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return string.Format("{0:00}:{1:00}", minutes, seconds);
    }

    private string FormatTimeWithMilliseconds(double timeInSeconds)
    {
        int milliseconds = (int)((timeInSeconds % 1d) * 1000d);
        int seconds = (int)timeInSeconds % 60;
        int minutes = (int)(timeInSeconds / 60d);
        return string.Format("{0:00}:{1:00}.{2:000}", minutes, seconds, milliseconds);
    }
}
