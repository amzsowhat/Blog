using UnityEditor;
using UnityEngine;
using UnityEngine.Audio;
using System.Collections.Generic;
using System.Linq;

public class AudioProfilerWindow : EditorWindow
{
    private class AudioPlaybackEvent
    {
        public string clipName;
        public string gameObjectName;
        public float startTime;
        public float? endTime;
        public AudioSource source;
        public AudioMixerGroup mixerGroup;
        public Color color;
        public float[] waveformSamples;
    }

    private List<AudioPlaybackEvent> playbackEvents = new List<AudioPlaybackEvent>();
    private Dictionary<AudioSource, AudioPlaybackEvent> activeSources = new Dictionary<AudioSource, AudioPlaybackEvent>();
    private Dictionary<AudioMixerGroup, Color> mixerGroupColors = new Dictionary<AudioMixerGroup, Color>();
    private Vector2 scrollPosition;
    private float timelineLength = 10f;
    private float pixelsPerSecond = 100f;
    private bool isRunning = true;
    private string searchFilter = "";

    private GUIStyle busLabelStyle;
    private GUIStyle trackLabelStyle;
    private GUIStyle clipLabelStyle;
    private GUIStyle durationLabelStyle;

    private const float leftPanelWidth = 200f;
    private const float timelineHeight = 28f;
    private const float timeRulerHeight = 24f;
    private const float rightPadding = 15f;

    [MenuItem("AudioTools/Audio Profiler Timeline")]
    public static void ShowWindow()
    {
        GetWindow<AudioProfilerWindow>("Audio Profiler Timeline");
    }

    private void OnEnable()
    {
        EditorApplication.update += UpdateAudioEvents;
        SetupStyles();
    }

    private void OnDisable()
    {
        EditorApplication.update -= UpdateAudioEvents;
    }

    private void SetupStyles()
    {
        busLabelStyle = new GUIStyle(EditorStyles.boldLabel)
        {
            fontSize = 12,
            normal = { textColor = Color.white }
        };

        trackLabelStyle = new GUIStyle(EditorStyles.label)
        {
            fontSize = 11,
            normal = { textColor = Color.white }
        };

        clipLabelStyle = new GUIStyle(EditorStyles.whiteLabel)
        {
            clipping = TextClipping.Clip,
            alignment = TextAnchor.MiddleLeft,
            fontSize = 10
        };

        durationLabelStyle = new GUIStyle(EditorStyles.whiteLabel)
        {
            alignment = TextAnchor.MiddleCenter,
            fontSize = 9,
            normal = { textColor = Color.white }
        };
    }

    private void UpdateAudioEvents()
    {
        if (!EditorApplication.isPlaying || !isRunning) return;

        float currentTime = Time.realtimeSinceStartup;
        AudioSource[] sources = FindObjectsOfType<AudioSource>();
        HashSet<AudioSource> seenThisFrame = new HashSet<AudioSource>();

        foreach (var src in sources)
        {
            seenThisFrame.Add(src);

            if (src.isPlaying)
            {
                if (!activeSources.ContainsKey(src))
                {
                    var group = src.outputAudioMixerGroup;
                    if (!mixerGroupColors.ContainsKey(group))
                        mixerGroupColors[group] = GetGroupColor(group);

                    var ev = new AudioPlaybackEvent
                    {
                        clipName = src.clip != null ? src.clip.name : "(Unnamed Clip)",
                        gameObjectName = src.gameObject.name,
                        startTime = currentTime,
                        endTime = null,
                        source = src,
                        mixerGroup = group,
                        color = mixerGroupColors[group],
                        waveformSamples = GetWaveformSamples(src.clip)
                    };
                    playbackEvents.Add(ev);
                    activeSources[src] = ev;
                }
            }
            else if (activeSources.ContainsKey(src))
            {
                activeSources[src].endTime = currentTime;
                activeSources.Remove(src);
            }
        }

        playbackEvents.RemoveAll(ev =>
        {
            bool endedLongAgo = ev.endTime.HasValue && (currentTime - ev.endTime.Value > timelineLength);
            return endedLongAgo || ev.source == null;
        });

        foreach (var pair in activeSources.ToList())
        {
            if (!seenThisFrame.Contains(pair.Key))
            {
                if (pair.Value != null)
                    pair.Value.endTime = currentTime;
                activeSources.Remove(pair.Key);
            }
        }

        Repaint();
    }

    private Color GetGroupColor(AudioMixerGroup group)
    {
        if (group == null) return Color.gray;
        int hash = group.GetInstanceID();
        return new Color(
            (hash & 0xFF) / 255f,
            ((hash >> 8) & 0xFF) / 255f,
            ((hash >> 16) & 0xFF) / 255f,
            0.8f
        );
    }

    private float[] GetWaveformSamples(AudioClip clip)
    {
        if (clip == null || clip.samples == 0) return null;

        try
        {
            int maxSamples = Mathf.Min(clip.samples, 44100 * 10);
            float[] data = new float[maxSamples * clip.channels];
            clip.GetData(data, 0);
            return data;
        }
        catch
        {
            return null;
        }
    }

    private void OnGUI()
    {
        DrawToolbar();
        DrawTimeline();
    }

    private void DrawToolbar()
    {
        GUILayout.BeginHorizontal(EditorStyles.toolbar);
        
        GUIContent playIcon = EditorGUIUtility.IconContent("PlayButton");
        GUIContent pauseIcon = EditorGUIUtility.IconContent("PauseButton");
        GUIContent stopIcon = EditorGUIUtility.IconContent("PreMatQuad");
        GUIContent clearIcon = EditorGUIUtility.IconContent("TreeEditor.Trash");
        
        if (GUILayout.Button(new GUIContent(playIcon.image, "Resume"), EditorStyles.toolbarButton, GUILayout.Width(30)))
            isRunning = true;
        
        if (GUILayout.Button(new GUIContent(pauseIcon.image, "Pause"), EditorStyles.toolbarButton, GUILayout.Width(30)))
            isRunning = false;
        
        if (GUILayout.Button(new GUIContent(stopIcon.image, "Stop All"), EditorStyles.toolbarButton, GUILayout.Width(30)))
            StopAllAudio();
        
        if (GUILayout.Button(new GUIContent(clearIcon.image, "Clear"), EditorStyles.toolbarButton, GUILayout.Width(30)))
        {
            playbackEvents.Clear();
            activeSources.Clear();
            mixerGroupColors.Clear();
        }
        
        GUILayout.Space(10);
        
        searchFilter = GUILayout.TextField(searchFilter, EditorStyles.toolbarSearchField, GUILayout.Width(200));
        
        GUILayout.FlexibleSpace();
        
        GUILayout.Label("Zoom:", EditorStyles.miniLabel);
        if (GUILayout.Button("+", EditorStyles.toolbarButton, GUILayout.Width(25)))
            pixelsPerSecond = Mathf.Min(pixelsPerSecond * 1.5f, 500f);
        if (GUILayout.Button("-", EditorStyles.toolbarButton, GUILayout.Width(25)))
            pixelsPerSecond = Mathf.Max(pixelsPerSecond / 1.5f, 50f);
        
        GUILayout.EndHorizontal();
    }

    private void StopAllAudio()
    {
        foreach (var source in activeSources.Keys.ToList())
        {
            if (source != null) source.Stop();
        }
        activeSources.Clear();
    }

    private void DrawTimeline()
    {
        float currentTime = Time.realtimeSinceStartup;
        float viewStart = Mathf.Max(0f, currentTime - timelineLength);
        float contentWidth = leftPanelWidth + (timelineLength * pixelsPerSecond) + rightPadding;
        
        scrollPosition = GUILayout.BeginScrollView(scrollPosition, false, false);
        
        DrawTimeRuler(viewStart, contentWidth);
        
        var filteredEvents = playbackEvents
            .Where(e => string.IsNullOrEmpty(searchFilter) || 
                   e.gameObjectName.Contains(searchFilter) || 
                   e.clipName.Contains(searchFilter))
            .GroupBy(e => e.mixerGroup)
            .OrderBy(g => g.Key?.name ?? "zzz");
        
        foreach (var group in filteredEvents)
        {
            GUILayout.BeginVertical("box");
            
            string displayBusName = group.Key != null ? group.Key.name.Replace("Audio", "").Trim() : "(No Bus)";
            GUILayout.Label(displayBusName, busLabelStyle);
            
            foreach (var ev in group.OrderBy(e => e.gameObjectName))
            {
                if (ev == null) continue;
                
                GUILayout.BeginHorizontal(GUILayout.Height(timelineHeight));
                
                // 左侧轨道信息区域
                GUILayout.BeginVertical(GUILayout.Width(leftPanelWidth));
                string displayTrackName = ev.gameObjectName.Replace("Audio", "").Trim();
                GUILayout.Label(displayTrackName, trackLabelStyle);
                GUILayout.Label(ev.clipName, clipLabelStyle);
                GUILayout.EndVertical();
                
                // 绘制左侧分割线（始终存在）
                float currentY = GUILayoutUtility.GetLastRect().y;
                EditorGUI.DrawRect(new Rect(leftPanelWidth, currentY, 1, timelineHeight), new Color(0.3f, 0.3f, 0.3f));
                
                // 右侧时间线区域
                Rect timelineRect = GUILayoutUtility.GetRect(contentWidth - leftPanelWidth, timelineHeight);
                
                // 绘制右侧分割线（只在有轨道时绘制）
                float rightBorderX = leftPanelWidth + (timelineLength * pixelsPerSecond);
                EditorGUI.DrawRect(new Rect(rightBorderX, currentY, 1, timelineHeight), new Color(0.3f, 0.3f, 0.3f));
                
                DrawAudioBlock(ev, timelineRect, viewStart, currentTime, rightBorderX, currentY);
                
                GUILayout.EndHorizontal();
            }
            
            GUILayout.EndVertical();
        }
        
        GUILayout.Space(timelineLength * pixelsPerSecond);
        GUILayout.EndScrollView();
    }

    private void DrawTimeRuler(float viewStart, float contentWidth)
    {
        Rect rulerRect = GUILayoutUtility.GetRect(contentWidth, timeRulerHeight);
        EditorGUI.DrawRect(rulerRect, new Color(0.1f, 0.1f, 0.1f));
        
        float currentTime = Time.realtimeSinceStartup;
        float seconds = Mathf.Floor(viewStart);
        float endTime = viewStart + timelineLength;
        float rightBorderX = leftPanelWidth + (timelineLength * pixelsPerSecond);
        
        while (seconds < endTime)
        {
            float xPos = leftPanelWidth + (seconds - viewStart) * pixelsPerSecond;
            if (xPos > leftPanelWidth && xPos < rightBorderX)
            {
                Rect markerRect = new Rect(xPos, rulerRect.y, 1, rulerRect.height);
                EditorGUI.DrawRect(markerRect, new Color(0.5f, 0.5f, 0.5f));
                
                string timeLabel = FormatTimeWithMilliseconds(seconds);
                Rect labelRect = new Rect(xPos + 2, rulerRect.y, 80, rulerRect.height);
                GUI.Label(labelRect, timeLabel, durationLabelStyle);
            }
            seconds += 1f;
        }
        
        // 当前时间指示线（与分割线样式一致）
        float currentX = leftPanelWidth + (currentTime - viewStart) * pixelsPerSecond;
        EditorGUI.DrawRect(new Rect(currentX, rulerRect.y, 1, rulerRect.height + 1000), new Color(0.3f, 0.3f, 0.3f));
    }

    private void DrawAudioBlock(AudioPlaybackEvent ev, Rect area, float viewStart, float currentTime, float rightBorderX, float startY)
    {
        if (ev == null) return;

        float start = ev.startTime;
        float end = ev.endTime ?? currentTime;
        float duration = end - start;

        float width = duration * pixelsPerSecond;
        float xPos = leftPanelWidth + (start - viewStart) * pixelsPerSecond;

        // 严格限制在左右分割线之间
        Rect blockRect = new Rect(
            Mathf.Max(xPos, leftPanelWidth + 1), // +1避免覆盖分割线
            startY, 
            Mathf.Min(width, rightBorderX - Mathf.Max(xPos, leftPanelWidth)), 
            timelineHeight
        );

        if (blockRect.width <= 0) return;

        // 绘制音频块
        EditorGUI.DrawRect(blockRect, ev.color);

        // 绘制波形
        if (ev.waveformSamples != null && ev.waveformSamples.Length > 0)
        {
            int samplesToDraw = Mathf.Min(ev.waveformSamples.Length, 200);
            float sampleStep = ev.waveformSamples.Length / (float)samplesToDraw;
            
            for (int i = 0; i < samplesToDraw; i++)
            {
                float sample = ev.waveformSamples[(int)(i * sampleStep)];
                float height = Mathf.Abs(sample) * blockRect.height * 0.8f;
                float yPos = blockRect.y + (blockRect.height - height) / 2;
                float x = blockRect.x + i * (blockRect.width / samplesToDraw);
                
                if (x + 1 <= rightBorderX)
                {
                    EditorGUI.DrawRect(new Rect(x, yPos, 1, height), Color.white);
                }
            }
        }

        // 显示时长（居中显示）
        string durationStr = FormatTimeWithMilliseconds(duration);
        GUI.Label(
            new Rect(
                blockRect.center.x - 40, 
                blockRect.y, 
                80, 
                blockRect.height
            ), 
            durationStr, 
            durationLabelStyle
        );
    }

    private string FormatTimeWithMilliseconds(float timeInSeconds)
    {
        int milliseconds = (int)((timeInSeconds % 1) * 1000);
        int seconds = (int)timeInSeconds % 60;
        int minutes = (int)(timeInSeconds / 60) % 60;
        return $"{minutes:00}:{seconds:00}.{milliseconds:000}";
    }
}
