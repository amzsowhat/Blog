# Audio Profiler Timeline

Unity Editor 音频播放时间线工具。

## 安装

将压缩包中的 `AudioProfiler` 文件夹和 `AudioProfiler.meta` 放入 Unity 项目的 `Assets/Editor/` 目录。等待 Unity 完成脚本编译后，在菜单栏打开 `AudioTools > Audio Profiler Timeline`。

## 使用

进入 Play Mode 后，窗口会记录场景内正在播放的 `AudioSource`，并按 `AudioMixerGroup` 分组显示。可使用搜索、暂停、恢复、停止全部音频、清空记录和缩放按钮查看时间线。

## 限制

工具只记录 Play Mode 中通过 `AudioSource` 播放的声音。波形预览依赖 `AudioClip.GetData`；无法读取采样数据的音频会继续显示事件，但不显示波形。
