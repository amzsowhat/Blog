# Audio Profiler Timeline

Unity Editor 的实时音频播放时间线工具。

## 安装

将 `AudioProfilerWindow.cs` 放入 Unity 项目的 `Assets/Editor/AudioTools/` 目录。Unity 会自动生成 `.meta` 文件，不需要从压缩包复制。

## 使用

在 Unity 菜单栏选择 `AudioTools > Audio Profiler Timeline`。进入 Play Mode 后，窗口默认显示 LIVE 时间线；点击 `REC` 开始捕获片段，点击 `STOP` 停止并切换到 CAPTURE 回看。Capture 数据可导出为 JSON。

## 范围

工具只追踪场景中通过 `AudioSource` 播放的声音。它用于 Unity Editor 内的播放行为检查，不用于分析构建后的播放器或绕过 `AudioSource` 的音频路径。
